var con = require('./connection');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));

app.set('view engine', 'ejs');

app.get('/', function (req, resp) {
    resp.sendFile(__dirname + '/logintry.html')
})
app.post('/', function (req, res) {
    var Roll=req.body.Roll
    var name = req.body.name;
    var Date_Of_Birth = req.body.Date_Of_Birth;
    var score = req.body.score;

    // con.connect(function (error) {
    //     if (error) throw error;

        var sql = "insert into students(Roll,name,Date_Of_Birth,score) values(?,?,?,?)";
        con.query(sql, [Roll,name,Date_Of_Birth,score], function (error, result) {
            if (error) throw error;
            res.redirect("/students");
            // res.send('Student Registered Successfully !!!'+result.insertId)
        })
    
    });

    app.get('/students', function (req, res) {
    

            var sql = "select * from students";
            con.query(sql, function (error, result) {
                if (error) console.log(error);
                res.render(__dirname + "/students", { students: result });
            })
        
});

console.log("I am working");
app.listen(7004);
