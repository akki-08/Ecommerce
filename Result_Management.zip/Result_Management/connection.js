var mysql = require('mysql');

var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"8860919288@Aaka",
    database:"resultManagement"
})

module.exports = con;